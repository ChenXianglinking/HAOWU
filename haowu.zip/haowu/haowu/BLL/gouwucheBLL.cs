﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLL
{
    public class gouwucheBLL
    {
        //返回购物车列表
        public static DataTable gouwuchelist(string userid)
        {
            return DAL.gouwucheDAL.gouwuchelist(userid);
        }
        //查询购物车每件商品价格
        public static DataTable getprice(string goodid, string guige)
        {
            return DAL.gouwucheDAL.getprice(goodid,guige);
        }
        //查询购物车每件商品数量
        public static DataTable getshopnum(string userid, string goodid, string guige)
        {
            return DAL.gouwucheDAL.getshopnum(userid,goodid,guige);
        }
        //购物车数量减一
        public static bool gouwuchegoodnumJianyi(string userid, string goodID,string mashuName)
        {
            return DAL.gouwucheDAL.gouwuchegoodnumJianyi(userid,goodID,mashuName);
        }
        //购物车数量加一
        public static bool gouwuchegoodnumJiayi(string userid, string goodID, string mashuName)
        {
            return DAL.gouwucheDAL.gouwuchegoodnumJiayi(userid, goodID, mashuName);
        }
        //返回购物车商品总价
        public static DataTable getgoodsNum(string userid, string goodid, string guige)
        {
            return DAL.gouwucheDAL.getgoodsNum(userid, goodid, guige);
        }
        //删除商品
        public static bool gouwucheDelGood(string userid, string goodID, string mashuName)
        {
            return DAL.gouwucheDAL.gouwucheDelGood(userid,goodID,mashuName);
        }
        //提交按钮
        public static bool tijiaoBtn(string userid)
        {
            return DAL.gouwucheDAL.tijiaoBtn(userid);
        }
    }
}
