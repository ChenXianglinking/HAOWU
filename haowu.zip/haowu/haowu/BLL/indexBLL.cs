﻿using System.Data;

namespace BLL
{
    public class indexBLL
    {
        //搜素按钮
        public static DataTable selectgoodname(string name)
        {
            return DAL.indexDAL.selectgoodname(name);
        }
        //主分类
        public static DataTable Navrep()
        {
            return DAL.indexDAL.Navrep();
        }
        //获取子分类
        public static DataTable ZiFenLeiRep()
        {
            return DAL.indexDAL.ZiFenLeiRep();
        }
        //获取子分类
        public static DataTable ZiFenLeiRep2()
        {
            return DAL.indexDAL.ZiFenLeiRep2();
        }
        //获取子分类
        public static DataTable ZiFenLeiRep3()
        {
            return DAL.indexDAL.ZiFenLeiRep3();
        }
        //获取子分类
        public static DataTable ZiFenLeiRep4()
        {
            return DAL.indexDAL.ZiFenLeiRep4();
        }
        //获取子分类
        public static DataTable ZiFenLeiRep5()
        {
            return DAL.indexDAL.ZiFenLeiRep5();
        }
        //获取孙分类
        //public static DataTable SunFenLeiRep()
        //{
        //    return DAL.indexDAL.SunFenLeiRep();
        //}
        //轮播图
        public static DataTable LunBoimg()
        {
            return DAL.indexDAL.LunBoimg();
        }
        //获取女士精选,查找商品表热卖前三
        public static DataTable MainContentRep1()
        {
            return DAL.indexDAL.MainContentRep1();
        }
        //获取男士精选,查找商品表热卖前三
        public static DataTable MainContentRep2()
        {
            return DAL.indexDAL.MainContentRep2();
        }
        //获取香水前三
        public static DataTable MainContentRep3()
        {
            return DAL.indexDAL.MainContentRep3();
        }
        //获取彩妆前三
        public static DataTable MainContentRep4()
        {
            return DAL.indexDAL.MainContentRep4();
        }
    }
}
