﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLL
{
    public class dengLuBLL
    {
        //登录
        public static DataTable getPhoneRow(string user, string Pwd)
        {
            return DAL.dengLuDAL.getPhoneRow(user,Pwd);
        }
        //注册
        public static bool insertuser(string pwd, string name, string sex, string phone, string email, string bir)
        {
            return DAL.dengLuDAL.insertuser(pwd,name,sex,phone,email,bir);
        }
    }
}
