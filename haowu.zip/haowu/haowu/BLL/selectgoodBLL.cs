﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLL
{
    public class selectgoodBLL
    {
        //rep
        public static DataTable selectgoodnamerep(string goodname)
        {
            return DAL.selectgoodDAL.selectgoodnamerep(goodname);
        }
    }
}
