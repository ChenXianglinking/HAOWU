﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLL
{
    public class houtaiBLL
    {
        //查询用户
        public static DataTable getUserRep()
        {
            return DAL.houtaiDAL.getUserRep();
        }
        //搜素用户
        public static DataTable searchUser(string user)
        {
            return DAL.houtaiDAL.searchUser(user);
        }
        //删除用户
        public static bool deluser(string userid)
        {
            return DAL.houtaiDAL.deluser(userid);
        }


        //查询商品
        public static DataTable getGoodRep()
        {
            return DAL.houtaiDAL.getGoodRep();
        }//商品码数表的库存
        public static DataTable getGoodMashu(string goodid)
        {
            return DAL.houtaiDAL.getGoodMashu(goodid);
        }
        //搜素商品
        public static DataTable searchGood(string good)
        {
            return DAL.houtaiDAL.searchGood(good);
        }
        //修改商品界面
        public static DataTable alertGoodjiemian(string good)
        {
            return DAL.houtaiDAL.alertGoodjiemian(good);
        }//修改商品界面的规格价格库存
        public static DataTable alertGoodjiemianmashu(string good)
        {
            return DAL.houtaiDAL.alertGoodjiemianmashu(good);
        }
        //修改商品按钮
        public static bool alertgood(string img, string name, string particulars, string caption, string craft, string id)
        {
            return DAL.houtaiDAL.alertgood(img,name,particulars,caption,craft,id);
        }//修改商品的码数库存表
        public static bool alertmashuKucunbiao(string id, string goodsSpecification, string price, string quantity)
        {
            return DAL.houtaiDAL.alertmashuKucunbiao(id, goodsSpecification,price, quantity);
        }//添加商品规格
        public static bool addmashuKucunbiao(string id, string mashuName, string price, string mashukucun)
        {
            return DAL.houtaiDAL.addmashuKucunbiao(id,mashuName,price,mashukucun);
        }//删除商品规格
        public static bool delmashuKucunbiao(string id, string mashuName)
        {
            return DAL.houtaiDAL.delmashuKucunbiao(id,mashuName);
        }


        //删除商品
        public static bool delgood(string goodid)
        {
            return DAL.houtaiDAL.delgood(goodid);
        }
        //添加商品界面的分类查询
        public static DataTable getGoodfenlei()
        {
            return DAL.houtaiDAL.getGoodfenlei();
        }
        //添加商品
        public static bool insertgood(string fenlei, string name, string imgs, string xijie, string shuoming, string gongyi)
        {
            return DAL.houtaiDAL.insertgood(fenlei, name, imgs, xijie, shuoming, gongyi);
        }//添加码数表
        public static DataTable getGoodid()
        {
            return DAL.houtaiDAL.getGoodid();
        }
        public static bool insertmashubiao(string goodid, string mashuName, string goodsPrice, string mashukucun)
        {
            return DAL.houtaiDAL.insertmashubiao(goodid,mashuName,goodsPrice,mashukucun);
        }




        //查询轮播图
        public static DataTable selectlunbo()
        {
            return DAL.houtaiDAL.selectlunbo();
        }
        //删除轮播图
        public static bool dellunbo(string lunboid)
        {
            return DAL.houtaiDAL.dellunbo(lunboid);
        }
        //添加轮播图
        public static bool insertlunbo(string lunboimg)
        {
            return DAL.houtaiDAL.insertlunbo(lunboimg);
        }
    }
}
