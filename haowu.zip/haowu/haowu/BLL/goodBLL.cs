﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLL
{
    public class goodBLL
    {
        //查询传过来得商品ID
        public static DataTable good(string id)
        {
            return DAL.goodDAL.good(id);
        }//查询商品规格库存
        public static DataTable goodguigekucun(string id)
        {
            return DAL.goodDAL.goodguigekucun(id);
        }
        //规格改变时，库存价格也改变
        public static DataTable selectkucunjiage(string id, string guige)
        {
            return DAL.goodDAL.selectkucunjiage(id,guige);
        }


        //添加到购物车
        public static bool insertgwc(string userid, string goodid, string guige)
        {
            return DAL.goodDAL.insertgwc(userid,goodid,guige);
        }
        //微信支付
        public static bool wxBtn(string goodid,string guige)
        {
            return DAL.goodDAL.wxBtn(goodid,guige);
        }
    }
}
