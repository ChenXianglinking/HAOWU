﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace BLL
{
    public class goodsWebBLL
    {
        //查询商品表
        public static DataTable RepBoxs(string fenleiid)
        {
            return DAL.goodsWebDAL.RepBoxs(fenleiid);
        }
        //得到商品价格
        public static DataTable getprice(string goodid)
        {
            return DAL.goodsWebDAL.getprice(goodid);
        }
        //得到分类name
        public static DataTable getfenleiname(string fenleiid)
        {
            return DAL.goodsWebDAL.getfenleiname(fenleiid);
        }
    }
}
