﻿using System;

namespace haowu
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //绑定nav的数据
                navrep.DataSource = BLL.indexBLL.Navrep();
                navrep.DataBind();
                zifenleiRep1.DataSource = BLL.indexBLL.ZiFenLeiRep();
                zifenleiRep1.DataBind();
                zifenleiRep2.DataSource = BLL.indexBLL.ZiFenLeiRep2();
                zifenleiRep2.DataBind();
                zifenleiRep3.DataSource = BLL.indexBLL.ZiFenLeiRep3();
                zifenleiRep3.DataBind();
                zifenleiRep4.DataSource = BLL.indexBLL.ZiFenLeiRep4();
                zifenleiRep4.DataBind();
                zifenleiRep5.DataSource = BLL.indexBLL.ZiFenLeiRep5();
                zifenleiRep5.DataBind();
                //绑定轮播图
                lunBoRep.DataSource = BLL.indexBLL.LunBoimg();
                lunBoRep.DataBind();
                //绑定精选
                mainContentRep1.DataSource = BLL.indexBLL.MainContentRep1();
                mainContentRep1.DataBind();
                mainContentRep2.DataSource = BLL.indexBLL.MainContentRep2();
                mainContentRep2.DataBind();
                mainContentRep3.DataSource = BLL.indexBLL.MainContentRep3();
                mainContentRep3.DataBind();
                mainContentRep4.DataSource = BLL.indexBLL.MainContentRep4();
                mainContentRep4.DataBind();
            }
        }
        //购物车按钮
        protected void gouwucheBtn_Click(object sender, EventArgs e)
        {
            string userID = "";
            try
            {
                userID = Request.Cookies["userid"].Value.ToString();
                //if (userID!=null)
                //{
                //    Response.Redirect("gouwuche.aspx?userID=" + userID);
                //}
            }
            catch (Exception)
            {
                Response.Redirect("dengLu.aspx");
            }
            if (userID != "")
            {
                Response.Redirect("gouwuche.aspx?userID=" + userID);
            }
        }
        //搜索商品按钮
        protected void selectgoodnameBtn_Click(object sender, EventArgs e)
        {
            string name = selectname.Value.ToString();
            if(BLL.indexBLL.selectgoodname(name).Rows.Count > 0)
            {
                Response.Redirect("selectgood.aspx?goodname=" + name);
            }
            else
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangText.InnerText = "没有找到商品！";
            }
        }

        protected void OKbtn_Click(object sender, EventArgs e)
        {
            tanChuangBg.Style.Value = "display:none;";
            tanChuang.Style.Value = "opacity: 0";
        }
    }
}