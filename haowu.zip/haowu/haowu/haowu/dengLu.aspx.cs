﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace haowu
{
    public partial class dengLu : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //绑定nav的数据
            navrep.DataSource = BLL.indexBLL.Navrep();
            navrep.DataBind();
        }
        //搜索商品按钮
        protected void selectgoodnameBtn_Click(object sender, EventArgs e)
        {
            string name = selectname.Value.ToString();
            if (BLL.indexBLL.selectgoodname(name).Rows.Count > 0)
            {
                Response.Redirect("selectgood.aspx?goodname=" + name);
            }
            else
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangText.InnerText = "没有找到商品！";
            }
        }
        //购物车按钮
        protected void gouwucheBtn_Click(object sender, EventArgs e)
        {
            string userID = "";
            try
            {
                userID = Request.Cookies["userid"].Value.ToString();
                //if (userID!=null)
                //{
                //    Response.Redirect("gouwuche.aspx?userID=" + userID);
                //}
            }
            catch (Exception)
            {
                Response.Redirect("dengLu.aspx");
            }
            if (userID != "")
            {
                Response.Redirect("gouwuche.aspx?userID=" + userID);
            }
        }
        //登录按钮
        protected void dengLuBtn_Click(object sender, EventArgs e)
        {
            //获取账号密码
            string dengLuPhone = dengLuPhoneOrEmail.Text.Trim();
            string dengLuPWD = miMadengLuPwd.Text.Trim();
            //查询
            DataTable dt = BLL.dengLuBLL.getPhoneRow(dengLuPhone, dengLuPWD);
            //查询表的行数是否大于0，大于就是找到了
            if (dt.Rows.Count > 0)
            {
                string userID = dt.Rows[0][0].ToString();
                //如果是管理员就登录到后台
                if (userID == "1")
                {
                    Response.Redirect("houtai.aspx?userID=" + userID);
                }
                //如果是用户就跳转到首页
                else
                {
                    //创建Cookie
                    HttpCookie userid = new HttpCookie("userid", userID);
                    //创建cookie生命周期
                    userid.Expires = DateTime.Now.AddDays(1);
                    //添加到Cookie集合中
                    Response.Cookies.Add(userid);
                    
                    Response.Redirect("index.aspx?userID=" + userID);
                }
            }
            else
            {
                tanChuangBg.Style.Add("display", "block");
                tanChuang.Style.Add("opacity", "1");
                tanChuangp.InnerText = "";
                tanChuangText.InnerText = "该用户不存在或密码错误！";
            }
        }

        //注册按钮
        protected void zhuCeBtn_Click(object sender, EventArgs e)
        {
            string Pwd1 = userPwd1.Text.Trim().ToString();
            string Pwd2 = userPwd2.Text.Trim().ToString();
            //判断两次密码是否一致
            if (Pwd1 == Pwd2)
            {
                string Phone = userPhone.Text.Trim().ToString();
                //判断手机号码是否有11位
                if (Phone.Length != 11)
                {
                    tanChuangBg.Style.Value = "display:block;";
                    tanChuang.Style.Value = "opacity: 1";
                    tanChuangp.InnerText = "";
                    tanChuangText.InnerText = "手机号不足11位！";
                }
                else
                {
                    //判断协议是否全部勾选
                    if (xy1.Checked == true && xy2.Checked == true && xy3.Checked == true)
                    {
                        string Email = userEmail.Text.Trim().ToLower().ToString();
                        

                        string xing = firsteName.Text.Trim().ToString();
                        string ming = lastName.Text.Trim().ToString();
                        string name = xing + ming;
                        string sex = sexValue.Value.ToString();
                        string shenRi = year.Value.ToString() + "-" + month.Value.ToString() + "-" + day.Value.ToString();
                        try
                        {
                            //插入数据库成功时
                            if (BLL.dengLuBLL.insertuser(Pwd1, name, sex, Phone, Email, shenRi))
                            {
                                tanChuangBg.Style.Value = "display:block;";
                                tanChuang.Style.Value = "opacity: 1";
                                tanChuangp.InnerText = "";
                                tanChuangText.InnerText = "注册成功！";
                            }
                        }
                        //插入数据库失败时
                        catch (Exception) {
                            tanChuangBg.Style.Value = "display:block;";
                            tanChuang.Style.Value = "opacity: 1";
                            tanChuangp.InnerText = "";
                            tanChuangText.InnerText = "注册失败！邮箱已注册！";
                        }
                    }
                    //协议未全部勾选
                    else
                    {
                        tanChuangBg.Style.Value = "display:block;";
                        tanChuang.Style.Value = "opacity: 1";
                        tanChuangp.InnerText = "";
                        tanChuangText.InnerText = "请同意协议！";
                    }
                }
                
            }
            //密码不一致时
            else
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangp.InnerText = "";
                tanChuangText.InnerText = "密码不一致！";
            }


        }
        
        public static int suijiFun()
        {
            //创建随机数对象
            Random r = new Random();
            //产生6位但不到7位的随机数
           int suiji = r.Next(100000, 1000000);
           return suiji;
        }
        //调用一下方法
        
        //注册通过手机号码获取验证码
        protected void getYZM_Click(object sender, EventArgs e)
        {
            //调用一下方法
            int i = suijiFun();
            tanChuangBg.Style.Add("display", "block");
            tanChuang.Style.Add("opacity", "1");
            tanChuangText.InnerText = i.ToString();
        }
        protected void OKbtn_Click(object sender, EventArgs e)
        {
            tanChuangBg.Style.Value = "display:none;";
            tanChuang.Style.Value = "opacity: 0";
        }
    }
}