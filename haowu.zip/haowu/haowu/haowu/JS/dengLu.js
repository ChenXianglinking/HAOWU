﻿var year = document.getElementById("year");
var month = document.getElementById("month");
var day = document.getElementById("day");

var zhanKai = document.getElementsByClassName("zhanKai");
var dengLu = document.getElementsByClassName("dengLu");
var zhuCe = document.getElementsByClassName("zhuCe");
//获取忘记密码后的提示文本
var wangJiMiMaBox = document.getElementsByClassName("wangJiMiMaBox")[0];
//获取忘记密码后的盒子
var phone = document.getElementsByClassName("phone")[0];
//获取新密码登录按钮元素
var newPwdDengLu = document.getElementById("newPwdDengLu");
//获取新密码取消按钮元素
var newPwdQuXiao = document.getElementById("newPwdQuXiao");
//登录状态图片
var zhanKaiImg0 = document.getElementsByClassName("zhanKaiImg")[0];
//注册状态图片
var zhanKaiImg1 = document.getElementsByClassName("zhanKaiImg")[1];
//获取忘记密码元素
var wjPwd = document.getElementById("wjPwd");
//展开状态
var zhanKaiType = 1;
//登录
zhanKai[0].onclick = function () {
    if (zhanKaiType) {
        dengLu[0].style.display = "block";
        zhanKaiImg0.src = "images/arrow_up.png";
        console.log('登录展开');
        zhanKaiType = 0;
    }
    else {
        dengLu[0].style.display = "none";
        zhanKaiImg0.src = "images/arrow_down.png";
        console.log('登录收起');
        zhanKaiType = 1;
    }
}
//注册
zhanKai[1].onclick = function () {
    if (zhanKaiType) {
        zhuCe[0].style.display = "block";
        zhanKaiImg1.src = "images/arrow_up.png";
        console.log('注册展开');
        zhanKaiType = 0;
    }
    else {
        zhuCe[0].style.display = "none";
        zhanKaiImg1.src = "images/arrow_down.png";
        console.log('注册收起');
        zhanKaiType = 1;
        
    }
}



//忘记密码
wjPwd.onclick = function () {
    zhanKai[0].style.display = "none";
    dengLu[0].style.display = "none";
    wangJiMiMaBox.style.display = "block";
    phone.style.display = "block";
    newPwdDengLu.style.display = "block";
    newPwdQuXiao.style.display = "block";
}
//取消忘记密码
newPwdQuXiao.onclick = function () {
    zhanKai[0].style.display = "block";
    dengLu[0].style.display = "block";
    wangJiMiMaBox.style.display = "none";
    phone.style.display = "none";
    newPwdDengLu.style.display = "none";
    newPwdQuXiao.style.display = "none";
}

//阻止事件冒泡，封装成方法好调用
function stopBubble(env) {
    // 如果提供事件对象，说明为非IE浏览器
    if (env && env.stopPropagation) {
        env.stopPropagation();
    } else {
        // IE浏览器
        window.event.cancelBubble = true;
    }
}

//var xy1 = document.querySelector("#xy1");
//var zhuCeBtn = document.querySelector("#zhuCeBtn");
//zhuCeBtn.addEventListener("click", function () {
//    if (xy1.checked) {

//    }
//})







var tanChuang = document.getElementById("tanChuang");
var tanChuangBg = document.getElementById("tanChuangBg");
var tanChuangText = document.getElementById("tanChuangText");
//获取验证码
var getYZM = document.getElementById("getYZM");
//getYZM.addEventListener('click', function (e) {
//    tanChuangBg.style.display = "block";
//    tanChuang.style.opacity = 1;
//    e.preventDefault(); //阻止事件默认行为
//    //stopBubble(e);
//})
//收到验证码确定
var YZMOK = document.getElementById("YZMOK");
YZMOK.addEventListener('click', function (e) {
    tanChuangBg.style.display = "none";
    tanChuang.style.opacity = 0;
    //e.preventDefault(); //阻止事件默认行为
})
