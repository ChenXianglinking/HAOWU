﻿//let weiXin = document.getElementById("wxBtn");
//let tanChuang = document.getElementById("tanChuang");
//let tanChuangBg = document.getElementById("tanChuangBg");

////weiXin.addEventListener('click', function (e) {
////    tanChuangBg.style.display = "block";
////    tanChuang.style.opacity = 1;
////    e.preventDefault(); //阻止事件默认行为
////    //stopBubble(e);
////})
////微信支付后确定
//var OK = document.getElementById("OK");
//OK.addEventListener('click', function (e) {
//    tanChuangBg.style.display = "none";
//    tanChuang.style.opacity = 0;
//    //e.preventDefault(); //阻止事件默认行为
//})