﻿
//获取右边Rep元素
var userBox = document.getElementsByClassName("userBox")[0];
var goodBox = document.getElementsByClassName("goodBox")[0];
var lunboBox = document.getElementsByClassName("lunboBox")[0];
//获取左边用户管理按钮
var userGM = document.getElementById("userGM");
//获取左边商品管理按钮
var goodGM = document.getElementById("goodGM");
//获取左边轮播图管理按钮
var lunboGM = document.getElementById("lunboGM");
//获得添加规格盒子按钮
var addguigeBoxBtn = document.getElementById("addguigeBoxBtn");
var alertBox = document.getElementById("alertBox");
var addguigeBoxID = document.getElementById("addguigeBoxID");
var addguigequxiaoBtn = document.getElementById("addguigequxiaoBtn");


userGM.addEventListener('click', function (e) {
    userGM.style.alignSelf = "flex-end";
    goodGM.style.alignSelf = "center";
    lunboGM.style.alignSelf = "center";
    userBox.style.display = "flex";
    goodBox.style.display = "none";
    lunboBox.style.display = "none";
})
goodGM.addEventListener('click', function (e) {
    userGM.style.alignSelf = "center";
    goodGM.style.alignSelf = "flex-end";
    lunboGM.style.alignSelf = "center";
    userBox.style.display = "none";
    goodBox.style.display = "flex";
    lunboBox.style.display = "none";
})
lunboGM.addEventListener('click', function (e) {
    userGM.style.alignSelf = "center";
    goodGM.style.alignSelf = "center";
    lunboGM.style.alignSelf = "flex-end";
    userBox.style.display = "none";
    goodBox.style.display = "none";
    lunboBox.style.display = "flex";
})
addguigeBoxBtn.addEventListener('click', function (e) {
    alertBox.style.display = "none";
    addguigeBoxID.style.display = "block";
    //禁止默认行为刷新
    e.preventDefault();
})
addguigequxiaoBtn.addEventListener('click', function (e) {
    alertBox.style.display = "block";
    addguigeBoxID.style.display = "none";
    //禁止默认行为刷新
    e.preventDefault();
})




//商品全选按钮
var quanxuancheck = document.querySelector("#quanxuancheck");
var goodchecks = document.querySelectorAll(".goodchecks");
quanxuancheck.addEventListener('click', function (e) {
    for (let j = 0; j < goodchecks.length; j++) {
        goodchecks[j].checked = true;
    }
})


//分类提示
//var insertfenleiIDBox = querySelector("#insertfenleiIDBox");
//insertfenleiIDBox.setAttribute("placeholder", "hi");