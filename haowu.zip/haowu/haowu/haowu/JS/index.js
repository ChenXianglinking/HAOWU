﻿var navbox = document.querySelectorAll(".navbox");
var navMuLu = document.querySelectorAll(".navMuLu");

//function over(i) {
//    navbox[i].style.borderBottom = "3px solid black";
//    navMuLu[i].style.display = "flex";
//}
//function out(i) {
//    window.setTimeout(function () {
//        navbox[i].style.borderBottom = "0";
//        navMuLu[i].style.display = "none";
//    }, 2000)
//}
//for (let i = 0; i < navbox.length; i++) {
//    navbox[i].onmouseover = over(i);
//    navbox[i].onmouseout = out(i);
//}


navbox[0].onmouseover = function () {
    navbox[0].style.borderBottom = "3px solid black";
    navMuLu[0].style.display = "flex";
}
navbox[0].onmouseout = function () {
    window.setTimeout(function () {
        navbox[0].style.borderBottom = "0";
        navMuLu[0].style.display = "none";
    }, 2000)
}

navbox[1].onmouseover = function () {
    navbox[1].style.borderBottom = "3px solid black";
    navMuLu[1].style.display = "flex";
}
navbox[1].onmouseout = function () {
    window.setTimeout(function () {
        navbox[1].style.borderBottom = "0";
        navMuLu[1].style.display = "none";
    }, 2000)
}


navbox[2].onmouseover = function () {
    navbox[2].style.borderBottom = "3px solid black";
    navMuLu[2].style.display = "flex";
}
navbox[2].onmouseout = function () {
    window.setTimeout(function () {
        navbox[2].style.borderBottom = "0";
        navMuLu[2].style.display = "none";
    }, 2000)
}

navbox[3].onmouseover = function () {
    navbox[3].style.borderBottom = "3px solid black";
    navMuLu[3].style.display = "flex";
}
navbox[3].onmouseout = function () {
    window.setTimeout(function () {
        navbox[3].style.borderBottom = "0";
        navMuLu[3].style.display = "none";
    }, 2000)
}

navbox[4].onmouseover = function () {
    navbox[4].style.borderBottom = "3px solid black";
    navMuLu[4].style.display = "flex";
}
navbox[4].onmouseout = function () {
    window.setTimeout(function () {
        navbox[4].style.borderBottom = "0";
        navMuLu[4].style.display = "none";
    }, 2000)
}

