﻿var selects = document.getElementsByClassName("selects");
for (var i = 0; i < selects.length; i++) {
    selects[i].onchange = function () {
        console.log("刷新了");
    }
}
