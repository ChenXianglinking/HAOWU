﻿var fixedBox = document.getElementsByClassName("fixedBox")[0];
var main = document.getElementsByClassName("main")[0];
var zhutiweibu = document.getElementsByClassName("zhutiweibu")[0];
var foot = document.getElementsByClassName("foot")[0];
let axis = 0;  // 如果需要记录累积量，可以用一个变量来存储下来
 window.onwheel = function (ev) {
     axis = ev.deltaY;
     console.log(axis);

     if (axis == 200) {
         fixedBox.style.display = "none";
     }
     if (axis == -200) {
         fixedBox.style.display = "block";
     }
}