﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace haowu
{
    public partial class houtai : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DropDownList1.DataSource = BLL.houtaiBLL.getGoodfenlei();
                DropDownList1.DataTextField = "fenleiName";
                DropDownList1.DataValueField = "fenLeiID";
                DropDownList1.DataBind();
            }
            userGMrep.DataSource = BLL.houtaiBLL.getUserRep();
            userGMrep.DataBind();
            goodGMRep.DataSource = BLL.houtaiBLL.getGoodRep();
            goodGMRep.DataBind();
            lunboRep.DataSource = BLL.houtaiBLL.selectlunbo();
            lunboRep.DataBind();
            
        }
        //获得码数库存表的商品库存
        public string getkucun(string goodid)
        {
            int kucunRows = BLL.houtaiBLL.getGoodMashu(goodid).Rows.Count;
            int kucun = 0;
            for(int i = 0; i < kucunRows; i++)
            {
                kucun += int.Parse(BLL.houtaiBLL.getGoodMashu(goodid).Rows[i][0].ToString());
            }
            return kucun.ToString();
        }
        //删除用户
        protected void deluser_Click(object sender, EventArgs e)
        {
            LinkButton sd = (LinkButton)sender;
            string userid = sd.CommandArgument.ToString();
            if (BLL.houtaiBLL.deluser(userid))
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangText.InnerText = "删除成功！";
            }
        }
        protected void OKbtn_Click(object sender, EventArgs e)
        {
            tanChuangBg.Style.Value = "display:none;";
            tanChuang.Style.Value = "opacity: 0";
        }
        //搜索用户
        protected void usersearchBtn_Click(object sender, EventArgs e)
        {
            string searchText = usersearch.Value.ToString();
            //如果搜索框为空，搜索全部
            if (searchText == "")
            {
                userGMrep.DataSource = BLL.houtaiBLL.getUserRep();
                userGMrep.DataBind();
            }
            //如果搜索框有内容
            else
            {
                //如果返回行数为0，就是没找到
                if (BLL.houtaiBLL.searchUser(searchText).Rows.Count == 0)
                {
                    tanChuangBg.Style.Value = "display:block;";
                    tanChuang.Style.Value = "opacity: 1";
                    tanChuangText.InnerText = "没有该用户！";
                }
                //不管找没找到，返回空的也行
                userGMrep.DataSource = BLL.houtaiBLL.searchUser(searchText);
                userGMrep.DataBind();
            }
        }
        //搜索商品
        protected void goodsearchBtn_Click(object sender, EventArgs e)
        {
            string searchText = goodsearch.Value.ToString();
            //如果搜索框为空，搜索全部
            if (searchText == "")
            {
                userGMrep.DataSource = BLL.houtaiBLL.getGoodRep();
                userGMrep.DataBind();
            }
            else
            {
                if (BLL.houtaiBLL.searchGood(searchText).Rows.Count == 0)
                {
                    tanChuangBg.Style.Value = "display:block;";
                    tanChuang.Style.Value = "opacity: 1";
                    tanChuangText.InnerText = "没有该商品！";
                }
                goodGMRep.DataSource = BLL.houtaiBLL.searchGood(searchText);
                goodGMRep.DataBind();
            }
        }
        //删除商品
        protected void delgood_Click(object sender, EventArgs e)
        {
            LinkButton sd = (LinkButton)sender;
            string goodid = sd.CommandArgument.ToString();
            if (BLL.houtaiBLL.delgood(goodid))
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangText.InnerText = "删除成功！";
            }
        }
        //修改商品界面
        protected void altergood_Click(object sender, EventArgs e)
        {
            alertBoxID.Style.Value = "display:block;";//修改界面出现，默认box隐藏
            searchBoxID.Style.Value = "display:none;";
            goodTableID.Style.Value = "display:none;";
            insertgoodbox.Style.Value = "display:none;";
            LinkButton sd = (LinkButton)sender;
            string goodsid = sd.CommandArgument.ToString();
            DataTable dt = BLL.houtaiBLL.alertGoodjiemian(goodsid);
            DataTable dt2 = BLL.houtaiBLL.alertGoodjiemianmashu(goodsid);
            goodsNameBox.Text = dt.Rows[0][2].ToString();
            goodsImgslabel.Text = dt.Rows[0][1].ToString();
            goodsSpecification.Text = dt2.Rows[0][1].ToString();    //商品规格
            goodsPriceBox.Text = string.Format("{0:N2}",dt2.Rows[0][2].ToString());
            goodsQuantityBox.Text = dt2.Rows[0][3].ToString();
            goodsParticularsBox.Text = dt.Rows[0][3].ToString();   //商品细节
            goodsCaptionBox.Text = dt.Rows[0][4].ToString();   //商品说明
            goodsCraftBox.Text = dt.Rows[0][5].ToString();
        }
        //确认修改按钮
        protected void quedingBtn_Click(object sender, EventArgs e)
        {
            string img = filealertimg.FileName.ToString();
            string name = goodsNameBox.Text.ToString();
            string Specification = goodsSpecification.Text.ToString();
            string price = goodsPriceBox.Text.ToString();
            string quantity = goodsQuantityBox.Text.ToString();
            string particular = goodsParticularsBox.Text.ToString();
            string caption = goodsCaptionBox.Text.ToString();
            string craft = goodsCraftBox.Text.ToString();
            string id = Request.QueryString["id"].ToString();
            //Button sd = (Button)sender;
            //string goodid = sd.CommandArgument.ToString();
            if (BLL.houtaiBLL.alertgood(img,name,particular,caption,craft,id))
            {
                if(BLL.houtaiBLL.alertmashuKucunbiao(id,Specification,price,quantity))
                {
                    tanChuangBg.Style.Value = "display:block;";//弹窗显示
                    tanChuang.Style.Value = "opacity: 1";
                    tanChuangText.InnerText = "修改成功！";

                    alertBoxID.Style.Value = "display:none;";//修改，添加界面隐藏，默认box展示
                    searchBoxID.Style.Value = "display:flex;";
                    goodTableID.Style.Value = "display:block;";
                    insertgoodbox.Style.Value = "display:none;";
                }
                
            }
            else
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangText.InnerText = "修改失败！";
            }
        }
        //修改取消按钮
        protected void alertquxiaoBtn_Click(object sender, EventArgs e)
        {
            alertBoxID.Style.Value = "display:none;";//修改，添加界面隐藏，默认box展示
            searchBoxID.Style.Value = "display:flex;";
            goodTableID.Style.Value = "display:block;";
            insertgoodbox.Style.Value = "display:none;";
        }
        //批量删除按钮
        protected void pldel_Click(object sender, EventArgs e)
        {
        }
        //添加商品按钮
        protected void intogood_Click(object sender, EventArgs e)
        {
            alertBoxID.Style.Value = "display:none;";////修改，默认box界面隐藏，添加界面展示
            searchBoxID.Style.Value = "display:none;";
            goodTableID.Style.Value = "display:none;";
            insertgoodbox.Style.Value = "display:block;";
        }
        //添加轮播按钮
        protected void intolunbo_Click(object sender, EventArgs e)
        {
            lunbotable.Style.Value = "display:none;";
            tianjialunbobox.Style.Value = "display:block;";
            lunbocaozuo.Style.Value = "display:none;";
        }
        //全选删除轮播按钮
        protected void dellunbo_Click(object sender, EventArgs e)
        {

        }
        //修改轮播按钮
        protected void xiugailunbo_Click(object sender, EventArgs e)
        {

        }
        //删除轮播按钮
        protected void dellunbo_Click1(object sender, EventArgs e)
        {
            LinkButton sd = (LinkButton)sender;
            string lunboid = sd.CommandArgument;
            if (BLL.houtaiBLL.dellunbo(lunboid))
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangText.InnerText = "删除成功！";
            }
        }

        
        //确认添加good按钮
        protected void querentianjiaBtn_Click(object sender, EventArgs e)
        {
            string insertfenlei = DropDownList1.SelectedValue.ToString();
            string insertname = insertgoodsNameBox.Text.ToString();
            string insertimg = FileUpload1.FileName.ToString();
            string insertSpecification = insertgoodsSpecification.Text.ToString();
            string insertprice = insertgoodsPriceBox.Text.ToString();
            string insertquantity = insertgoodsQuantityBox.Text.ToString();
            string insertparticular = insertgoodsParticularsBox.Text.ToString();
            string insertcaption = insertgoodsCaptionBox.Text.ToString();
            string insertcraft = insertgoodsCraftBox.Text.ToString();
            bool tfgood = BLL.houtaiBLL.insertgood(insertfenlei, insertname, insertimg, insertparticular, insertcaption, insertcraft);
            bool tfmashubiao = false;
            if (tfgood)
            {
                string goodid = BLL.houtaiBLL.getGoodid().Rows[0][0].ToString();
                tfmashubiao = BLL.houtaiBLL.insertmashubiao(goodid, insertSpecification, insertprice, insertquantity);
            }
            if (tfgood && tfmashubiao)
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangText.InnerText = "添加成功！";

                insertgoodsNameBox.Text = "";
                insertgoodsSpecification.Text = "";
                insertgoodsPriceBox.Text = "";
                insertgoodsQuantityBox.Text = "";
                insertgoodsParticularsBox.Text = "";
                insertgoodsCaptionBox.Text = "";
                insertgoodsCraftBox.Text = "";

                alertBoxID.Style.Value = "display:none;";//修改，添加界面隐藏，默认box展示
                searchBoxID.Style.Value = "display:flex;";
                goodTableID.Style.Value = "display:block;";
                insertgoodbox.Style.Value = "display:none;";
            }
            else
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangText.InnerText = "添加失败！";
            }
        }
        //取消添加good按钮
        protected void tianjiaquxiaoBtn_Click(object sender, EventArgs e)
        {
            alertBoxID.Style.Value = "display:none;";//修改，添加界面隐藏，默认box展示
            searchBoxID.Style.Value = "display:flex;";
            goodTableID.Style.Value = "display:block;";
            insertgoodbox.Style.Value = "display:none;";
        }
        //轮播添加确认按钮
        protected void lunbotianjiaquerenBtn_Click(object sender, EventArgs e)
        {
            string lunboimg = tianjialunboimg.Text.ToString();
            if (BLL.houtaiBLL.insertlunbo(lunboimg))
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangText.InnerText = "添加成功！";

                tianjialunbobox.Style.Value = "display:none;";
                lunbotable.Style.Value = "display:block;";
                lunbocaozuo.Style.Value = "display:flex;";
            }
        }
        //轮播添加取消按钮
        protected void lunbotianjiaquxiaoBtn_Click(object sender, EventArgs e)
        {
            tianjialunbobox.Style.Value = "display:none;";
            lunbotable.Style.Value = "display:block;";
            lunbocaozuo.Style.Value = "display:flex;";
        }

        
    }
}