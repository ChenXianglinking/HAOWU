﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace haowu
{
    public partial class good : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            //绑定nav的数据
            navrep.DataSource = BLL.indexBLL.Navrep();
            navrep.DataBind();
            //获取传过来的商品ID
            string id = Request.QueryString["goodsId"];
            DataTable dt = BLL.goodBLL.good(id);
            DataTable guigedt = BLL.goodBLL.goodguigekucun(id); //获得商品规格库存表

            goodimg.ImageUrl = "images/" + dt.Rows[0][3].ToString();
            goodname.Text = dt.Rows[0][2].ToString();
            xijie.Text = dt.Rows[0][4].ToString();
            shuoming.Text = dt.Rows[0][5].ToString();
            gongyi.Text = dt.Rows[0][6].ToString();
            price.Text = string.Format("{0:C2}", double.Parse(guigedt.Rows[0][2].ToString()));
            if (!IsPostBack)
            {
                DropDownList1.DataSource = BLL.goodBLL.goodguigekucun(id);
                DropDownList1.DataTextField = "mashuName";
                DropDownList1.DataValueField = "mashuName";
                DropDownList1.DataBind();
            }
            kucun.Text = "库存:" + BLL.goodBLL.selectkucunjiage(id, DropDownList1.SelectedValue).Rows[0][3].ToString();
        }
        public string goodid()
        {
            string id = Request.QueryString["goodsId"];
            return id;
        }

        //添加到购物车按钮
        protected void insertshopButton_Click(object sender, EventArgs e)
        {
            string userID = "";
            try
            {
                userID = Request.Cookies["userid"].Value.ToString();
            }
            catch (Exception)
            {
                Response.Redirect("dengLu.aspx");
            }
            string goodid = Request.QueryString["goodsId"];
            string guige = DropDownList1.Text.ToString();
            if (BLL.goodBLL.insertgwc(userID, goodid, guige))
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangp.InnerText = "";
                tanChuangText.InnerText = "添加数量成功！";
                OKbtn.Style.Value = "display:none;";
                Nobtn.Style.Value = "display:none;";
                quedingbtn.Style.Value = "display:block;";
            }
            else
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangp.InnerText = "";
                tanChuangText.InnerText = "添加购物车成功！";
                OKbtn.Style.Value = "display:none;";
                Nobtn.Style.Value = "display:none;";
                quedingbtn.Style.Value = "display:block;";
            }
        }
        //搜索商品按钮
        protected void selectgoodnameBtn_Click(object sender, EventArgs e)
        {
            string name = selectname.Value.ToString();
            if (BLL.indexBLL.selectgoodname(name).Rows.Count > 0)
            {
                Response.Redirect("selectgood.aspx?goodname=" + name);
            }
            else
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangp.InnerText = "";
                tanChuangText.InnerText = "没有找到商品！";
                OKbtn.Style.Value = "display:none;";
                Nobtn.Style.Value = "display:none;";
                quedingbtn.Style.Value = "display:block;";
            }
        }
        //购物车按钮
        protected void gouwucheBtn_Click(object sender, EventArgs e)
        {
            string userID = "";
            try
            {
                userID = Request.Cookies["userid"].Value.ToString();
            }
            catch (Exception)
            {
                Response.Redirect("dengLu.aspx");
            }
            if (userID != "")
            {
                Response.Redirect("gouwuche.aspx?userID=" + userID);
            }
        }
        //微信支付
        
        protected void wxButton_Click(object sender, EventArgs e)
        {
            tanChuangBg.Style.Value = "display:block;";
            tanChuang.Style.Value = "opacity: 1";
            tanChuangp.InnerText = "微信支付";
            tanChuangText.InnerHtml = "<img src='images/weiXin.jpg' />";
            OKbtn.Style.Value = "display:block;";
            Nobtn.Style.Value = "display:block;";
            quedingbtn.Style.Value = "display:none;";
        }

        //微信支付弹窗支付成功按钮
        protected void OKbtn_Click(object sender, EventArgs e)
        {
            //商品已售加一
            
            string goodid = Request.QueryString["goodsId"];
            string guige = DropDownList1.Text.ToString();
            BLL.goodBLL.wxBtn(goodid,guige);
            tanChuangBg.Style.Value = "display:none;";
            tanChuang.Style.Value = "opacity: 0";
            OKbtn.Style.Value = "display:none;";
            Nobtn.Style.Value = "display:none;";
            quedingbtn.Style.Value = "display:none;";
            kucun.Text = "库存:" + BLL.goodBLL.selectkucunjiage(goodid, DropDownList1.SelectedValue).Rows[0][3].ToString();
        }
        //取消支付
        protected void Nobtn_Click(object sender, EventArgs e)
        {
            tanChuangBg.Style.Value = "display:none;";
            tanChuang.Style.Value = "opacity: 0";
            OKbtn.Style.Value = "display:none;";
            Nobtn.Style.Value = "display:none;";
            quedingbtn.Style.Value = "display:block;";
        }
        //搜索结果确定按钮
        protected void quedingbtn_Click(object sender, EventArgs e)
        {
            tanChuangBg.Style.Value = "display:none;";
            tanChuang.Style.Value = "opacity: 0";
            OKbtn.Style.Value = "display:none;";
            Nobtn.Style.Value = "display:none;";
            quedingbtn.Style.Value = "display:block;";
        }
        //规格改变时,库存价格跟着改变
        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string goodid = Request.QueryString["goodsId"];
            string guige = DropDownList1.SelectedValue;
            DataTable dt = BLL.goodBLL.selectkucunjiage(goodid, guige);
            string kc = "库存:" + dt.Rows[0][3].ToString();
            string pr = String.Format("{0:C2}", double.Parse(dt.Rows[0][2].ToString()));
            kucun.Text = kc;
            price.Text = pr;
        }

        
    }
}