﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace haowu
{
    public partial class goodsWeb : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //绑定nav的数据
            navrep.DataSource = BLL.indexBLL.Navrep();
            navrep.DataBind();
            //获取首页传过来的分类ID
            string id = Request.QueryString["fenLeiID"];
            //利用分类ID去查询，并绑定数据给rep
            goods.DataSource = BLL.goodsWebBLL.RepBoxs(id);
            goods.DataBind();

        }
        //获得价格
        public string goodsprice(string goodid)
        {
            string price = String.Format("{0:C2}", double.Parse( BLL.goodsWebBLL.getprice(goodid).Rows[0][0].ToString()) );
            return price;
        }


        //购物车按钮
        protected void gouwucheBtn_Click(object sender, EventArgs e)
        {
            string userID = "";
            try
            {
                userID = Request.Cookies["userid"].Value.ToString();
                //if (userID!=null)
                //{
                //    Response.Redirect("gouwuche.aspx?userID=" + userID);
                //}
            }
            catch (Exception)
            {
                Response.Redirect("dengLu.aspx");
            }
            if (userID != "")
            {
                Response.Redirect("gouwuche.aspx?userID=" + userID);
            }
        }
        //搜索商品按钮
        protected void selectgoodnameBtn_Click(object sender, EventArgs e)
        {
            string name = selectname.Value.ToString();
            if (BLL.indexBLL.selectgoodname(name).Rows.Count > 0)
            {
                Response.Redirect("selectgood.aspx?goodname=" + name);
            }
            else
            {
                tanChuangBg.Style.Value = "display:block;";
                tanChuang.Style.Value = "opacity: 1";
                tanChuangText.InnerText = "没有找到商品！";
            }
        }
        //获得分类名字
        public string fenleiName()
        {
            string fenleiname = Request.QueryString["fenLeiID"];
            string name = BLL.goodsWebBLL.getfenleiname(fenleiname).Rows[0][0].ToString();
            return name;
        }

        protected void OKbtn_Click(object sender, EventArgs e)
        {
            tanChuangBg.Style.Value = "display:none;";
            tanChuang.Style.Value = "opacity: 0";
        }
    }
}