﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DAL
{
    public class dengLuDAL
    {
        //登录
        public static DataTable getPhoneRow(string user, string Pwd)
        {
            string sql = string.Format("select * from users where userPhone='{0}' and userPwd='{1}' or userEmail='{0}'", user,Pwd);
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //注册
        public static bool insertuser(string pwd,string name, string sex,string phone,string email,string bir)
        {
            string sql = string.Format("insert into users values ('{0}','{1}','{2}','{3}','{4}','{5}',getdate(),'0')",pwd,name,sex,phone,email,bir);
            bool tf = DAL.DBHelp.executeNonQuery(sql);
            return tf;
        }
    }
}
