﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DAL
{
    public class houtaiDAL
    {
        //查询用户
        public static DataTable getUserRep()
        {
            string sql = "select userID, userName,userSex,userPhone,userEmail,userBirthday,userTime,userJiFen from users  where userID != 1";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //搜素用户
        public static DataTable searchUser(string user)
        {
            string sql = "select userID,userName,userSex,userPhone,userEmail,userBirthday,userTime,userJiFen from users where userID != 1 and userName like '%"+user+"%'";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //删除用户
        public static bool deluser(string userid)
        {
            string sql = "delete users where userID=" + userid;
            bool tf = DAL.DBHelp.executeNonQuery(sql);
            return tf;
        }


        //查询商品
        public static DataTable getGoodRep()
        {
            string sql = "select goodsID,goodsImgs,goodsName,goodsShelfTime,goodsSelling from goods";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }//商品码数表的库存
        public static DataTable getGoodMashu(string goodid)
        {
            string sql = "select mashukucun from mashubiao where goods=" + goodid;
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //搜素商品
        public static DataTable searchGood(string good)
        {
            string sql = "select goodsID,goodsImgs,goodsName,goodsShelfTime,goodsSelling from goods where goodsName like '%" + good + "%'";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //修改商品界面
        public static DataTable alertGoodjiemian(string good)
        {
            string sql = "select goodsID,goodsImgs,goodsName,goodsParticulars,goodsCaption,goodsCraft from goods where goodsID=" + good;
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }//修改商品界面的规格价格库存
        public static DataTable alertGoodjiemianmashu(string good)
        {
            string sql = "select * from mashubiao where goods=" + good;
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //修改商品
        public static bool alertgood(string img,string name, string particulars, string caption, string craft, string id)
        {
            string sql = string.Format("update goods set goodsImgs='{0}',goodsName='{1}',goodsParticulars='{2}',goodsCaption='{3}',goodsCraft='{4}' where goodsID='{5}'", img,name,particulars,caption,craft,id);
            bool tf = DAL.DBHelp.executeNonQuery(sql);
            return tf;
        }//修改商品的码数库存表
        public static bool alertmashuKucunbiao(string id, string goodsSpecification, string price, string quantity)
        {
            string sql = string.Format("update mashubiao set goodsPrice='{2}',mashukucun='{3}' where goods='{0}' and mashuName='{1}'", id, goodsSpecification, price, quantity);
            bool tf = DAL.DBHelp.executeNonQuery(sql);
            return tf;
        }//添加商品规格
        public static bool addmashuKucunbiao(string id, string mashuName, string price, string mashukucun)
        {
            string sql = string.Format("insert into mashubiao values ('{0}','{1}','{2}','{3}')", id, mashuName, price, mashukucun);
            bool tf = DAL.DBHelp.executeNonQuery(sql);
            return tf;
        }//删除商品规格
        public static bool delmashuKucunbiao(string id, string mashuName)
        {
            string sql = string.Format("delete mashubiao where goods='{0}' and mashuName='{1}'", id, mashuName);
            bool tf = DAL.DBHelp.executeNonQuery(sql);
            return tf;
        }

        //删除商品
        public static bool delgood(string goodid)
        {
            string sql = String.Format("delete shoppingCart where goodsID={0} delete goods where goodsID={0}",goodid);
            bool tf = DAL.DBHelp.executeNonQuery(sql);
            return tf;
        }
        //添加商品界面的分类查询
        public static DataTable getGoodfenlei()
        {
            string sql = "select * from fenLei where shangJiFenLeiID!=0";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //添加商品
        public static bool insertgood(string fenlei,string name,string imgs,string xijie,string shuoming,string gongyi)
        {
            string sql = String.Format("insert into goods values ('{0}','{1}','{2}','{3}','{4}','{5}',getdate(),'0')", fenlei, name,imgs,xijie,shuoming,gongyi);
            bool tf = DAL.DBHelp.executeNonQuery(sql);
            return tf;
        }//添加码数表
        public static DataTable getGoodid()
        {
            string sql = "select top(1)goodsID from goods order by goodsID desc";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        public static bool insertmashubiao(string goodid,string mashuName,string goodsPrice,string mashukucun)
        {
            string sql = String.Format("insert into mashubiao values('{0}','{1}','{2}','{3}')",goodid,mashuName,goodsPrice,mashukucun);
            bool tf = DAL.DBHelp.executeNonQuery(sql);
            return tf;
        }









        //查询轮播图
        public static DataTable selectlunbo()
        {
            string sql = "select * from lunBoTu";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //删除轮播图
        public static bool dellunbo(string lunboid)
        {
            string sql = "delete lunBoTu where lunBoID="+lunboid;
            bool tf = DAL.DBHelp.executeNonQuery(sql);
            return tf;
        }
        //添加轮播图
        public static bool insertlunbo(string lunboimg)
        {
            string sql = "insert into lunBoTu values('"+lunboimg+"')";
            bool tf = DAL.DBHelp.executeNonQuery(sql);
            return tf;
        }
    }
}
