﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DAL
{
    public class selectgoodDAL
    {
        //rep
        public static DataTable selectgoodnamerep(string goodname)
        {
            string sql = "select * from goods a,mashubiao b where a.goodsID=b.goods and goodsName like '%" + goodname + "%'";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
    }
}
