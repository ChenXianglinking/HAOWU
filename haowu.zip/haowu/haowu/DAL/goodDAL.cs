﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DAL
{
    public class goodDAL
    {
        //查询传过来得商品ID
        public static DataTable good(string id)
        {
            string sql = "select * from goods where goodsID = " + id;
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }//查询商品规格库存
        public static DataTable goodguigekucun(string id)
        {
            string sql = "select * from mashubiao where goods=" + id;
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //规格改变时，库存价格也改变
        public static DataTable selectkucunjiage(string id, string guige)
        {
            string sql = string.Format("select * from mashubiao where goods='{0}' and mashuName='{1}'",id,guige);
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }


        //添加到购物车，先查询，如果有该商品，数量加一。如果购物车没有该商品，直接添加
        public static bool insertgwc(string userid, string goodid, string guige)
        {
            string selectsql = String.Format("select * from shoppingCart where userID='{0}' and goodsID='{1}' and mashuName='{2}'", userid,goodid,guige);
            DataTable dt = DAL.DBHelp.GetDataTable(selectsql);
            bool tf = false;
            if (dt.Rows.Count > 0)
            {//数量加一
                string sql = string.Format("update shoppingCart set shopQuantity=shopQuantity+1 where userID='{0}' and goodsID='{1}' and mashuName='{2}'", userid, goodid, guige);
                tf = DAL.DBHelp.executeNonQuery(sql);//加一成功返回tf=真,因为真会弹出数量加一，假则是商品加一
            }
            else
            {//直接添加
                string sql = string.Format("insert into shoppingCart values ('{0}','{1}','{2}',1)", userid, goodid, guige);
                DAL.DBHelp.executeNonQuery(sql);
            }
            return tf;
        }
        //微信支付
        public static bool wxBtn(string goodid, string guige)
        {
            string upkucun = string.Format("update mashubiao set mashukucun=mashukucun-1 where goods='{0}' and mashuName='{1}'",goodid,guige);
            bool upkucumtf = DAL.DBHelp.executeNonQuery(upkucun);
            if (upkucumtf)
            {
                string sql = "update goods set goodsSelling=goodsSelling+1 where goodsID=" + goodid;
                bool tf = DAL.DBHelp.executeNonQuery(sql);
            }
            return upkucumtf;
        }
    }
}
