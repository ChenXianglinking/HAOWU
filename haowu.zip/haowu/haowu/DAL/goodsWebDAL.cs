﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;


namespace DAL
{
    public class goodsWebDAL
    {
        //查询商品表
        public static DataTable RepBoxs(string fenleiid)
        {
            string sql = "select * from goods a, fenLei b where  a.fenleiID = b.fenLeiID and b.shangJiFenLeiID =" + fenleiid;
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            if(dt.Rows.Count == 0)
            {
                    string sql2 = "select * from goods a, fenLei b where  a.fenleiID = b.fenLeiID and b.fenLeiID =" + fenleiid;
                    dt = DAL.DBHelp.GetDataTable(sql2);
            }
            return dt;
        }
        //得到商品价格
        public static DataTable getprice(string goodid)
        {
            string sql = "select goodsPrice from mashubiao where goods=" + goodid;
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //得到分类name
        public static DataTable getfenleiname(string fenleiid)
        {
            string sql = "select fenleiName from fenLei where fenLeiID=" + fenleiid;
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
    }
}
