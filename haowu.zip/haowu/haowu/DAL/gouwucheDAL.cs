﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DAL
{
    public class gouwucheDAL
    {
        
        
        //返回购物车列表
        public static DataTable gouwuchelist(string userid)
        {
            string sql = "select * from goods a, shoppingCart b where a.goodsID=b.goodsID and b.userID=" + userid;
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //查询购物车每件商品价格
        public static DataTable getprice(string goodid,string guige)
        {
            string sql = string.Format("select * from mashubiao where goods='{0}' and mashuName='{1}'", goodid, guige);
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //查询购物车每件商品数量
        public static DataTable getshopnum(string userid, string goodid, string guige)
        {
            string sql = string.Format("select * from shoppingCart where userID='{0}' and goodsID='{1}' and mashuName='{2}'",userid,goodid,guige);
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //购物车数量减一
        public static bool gouwuchegoodnumJianyi(string userid,string goodID,string mashuName)
        {
            string sql = String.Format("update shoppingCart set shopQuantity=shopQuantity-1 where userID='{0}' and goodsID = '{1}' and mashuName='{2}'", userid,goodID,mashuName);
            bool i = DAL.DBHelp.executeNonQuery(sql);
            return i;
        }
        //购物车数量加一
        public static bool gouwuchegoodnumJiayi(string userid, string goodID, string mashuName)
        {
            string sql = String.Format("update shoppingCart set shopQuantity=shopQuantity+1 where userID='{0}' and goodsID = '{1}' and mashuName='{2}'", userid, goodID, mashuName);
            bool i = DAL.DBHelp.executeNonQuery(sql);
            return i;
        }
        //返回购物车商品总价
        public static DataTable getgoodsNum(string userid, string goodid, string guige)
        {
            string sql = string.Format("select * from shoppingCart where userID='{0}' and goodsID='{1}' and mashuName='{2}'", userid, goodid, guige);
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //删除商品
        public static bool gouwucheDelGood(string userid, string goodID,string mashuName)
        {
            string sql = String.Format("delete shoppingCart where userID='{0}' and goodsID='{1}' and mashuName='{2}'", userid, goodID, mashuName);
            bool i = DAL.DBHelp.executeNonQuery(sql);
            return i;
        }
        //提交按钮
        public static bool tijiaoBtn(string userid)
        {
            //先查询出该用户购物车的所有商品ID
            string selectidmashuName = "select a.goodsID,a.mashuName  from shoppingCart a , goods b where a.goodsID=b.goodsID and a.userID=" + userid;
            DataTable dt = DAL.DBHelp.GetDataTable(selectidmashuName);
            //循环将商品已售加一,对应规格的库存减一
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string goodsid = dt.Rows[i][0].ToString();
                string goodsmashuName = dt.Rows[i][1].ToString();
                string update = string.Format("update goods set goodsSelling=goodsSelling+1 where goodsID='{0}'",goodsid);
                string delstr = string.Format("update mashubiao set mashukucun=mashukucun-1 where goods='{0}' and mashuName='{1}'",goodsid, goodsmashuName);
                DataTable updt = DAL.DBHelp.GetDataTable(update);
                DataTable deldt = DAL.DBHelp.GetDataTable(delstr);
            }
            //执行清空购物车语句
            string del = "delete shoppingCart where userID=" + userid;
            bool tf = DAL.DBHelp.executeNonQuery(del);
            return tf;
        }
    }
}
