﻿using System.Data;

namespace DAL
{
    public class indexDAL
    {
        //搜素按钮
        public static DataTable selectgoodname(string name)
        {
            string sql = "select * from goods where goodsName like '%"+name+"%'";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //获取主分类
        public static DataTable Navrep()
        {
            string sql = "select * from fenLei where shangJiFenLeiID=0";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //获取子分类1
        public static DataTable ZiFenLeiRep()
        {
            string sql = "select * from fenLei where shangJiFenLeiID=1";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //获取子分类2
        public static DataTable ZiFenLeiRep2()
        {
            string sql = "select * from fenLei where shangJiFenLeiID=2";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //获取子分类3
        public static DataTable ZiFenLeiRep3()
        {
            string sql = "select * from fenLei where shangJiFenLeiID=3";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //获取子分类4
        public static DataTable ZiFenLeiRep4()
        {
            string sql = "select * from fenLei where shangJiFenLeiID=4";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //获取子分类5
        public static DataTable ZiFenLeiRep5()
        {
            string sql = "select * from fenLei where shangJiFenLeiID=5";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //轮播图
        public static DataTable LunBoimg()
        {
            string sql = "select* from lunBoTu";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //获取女士精选,查找商品表热卖前三
        public static DataTable MainContentRep1()
        {
            string sql = "select top 3 * from goods A, fenLei B where A.fenLeiID = B.fenLeiID and shangJiFenLeiID = 2 order by goodsSelling desc";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //获取男士精选,查找商品表热卖前三
        public static DataTable MainContentRep2()
        {
            string sql = "select top 3 * from goods A, fenLei B where A.fenLeiID = B.fenLeiID and shangJiFenLeiID = 1 order by goodsSelling desc";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //获取香水前三
        public static DataTable MainContentRep3()
        {
            string sql = "select top 3 * from goods A, fenLei B where A.fenLeiID = B.fenLeiID and shangJiFenLeiID = 3 order by goodsSelling desc";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
        //获取彩妆前三
        public static DataTable MainContentRep4()
        {
            string sql = "select top 3 * from goods A, fenLei B where A.fenLeiID = B.fenLeiID and shangJiFenLeiID = 4 order by goodsSelling desc";
            DataTable dt = DAL.DBHelp.GetDataTable(sql);
            return dt;
        }
    }
}
