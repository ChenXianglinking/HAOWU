﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    internal class DBHelp
    {
        public static string connstr = @"Data Source=.;Initial Catalog=haowu;Integrated Security=True";
        public static SqlConnection conn = new SqlConnection(connstr);

        public static DataTable GetDataTable(string sql)
        {
            try
            {
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                conn.Open();
                DataTable dt = new DataTable();
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception) { throw; }
        }

        public static bool executeNonQuery(string sql)
        {
            try
            {
                SqlCommand comm = new SqlCommand(sql, conn);
                conn.Open();
                int i = comm.ExecuteNonQuery();
                conn.Close();
                return i > 0;
            }
            catch (Exception) { throw; }
        }
    }
}
